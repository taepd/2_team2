package kr.or.bit.dto;

public class QnaNick extends Qna{
	
	String nick;

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}
	
	

}
